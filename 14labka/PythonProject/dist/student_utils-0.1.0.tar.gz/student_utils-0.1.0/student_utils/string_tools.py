def to_upper(text):
    return text.upper()

def count_words(text):
    return len(text.split())

def reverse_string(text):
    return text[::-1]
